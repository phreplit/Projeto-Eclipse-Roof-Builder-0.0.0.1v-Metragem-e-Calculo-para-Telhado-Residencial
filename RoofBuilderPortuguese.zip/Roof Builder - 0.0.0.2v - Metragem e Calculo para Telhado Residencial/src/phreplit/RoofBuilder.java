
// Author: PHNO - Tecnólogo | Pós-Graduado
// Data Release: 31/10/2024
// Versão Código: 0.0.0.2v
// Replit: @PHNO, @PHREPLIT
// E-mail: phreplit@gmail.com

// Software: Roof Builder - 0.0.0.2v - Metragem e Calculo para Telhado Residencial, com interface grafica e compilacao em ambiente desktop.

package phreplit;

			import java.awt.EventQueue;

			import javax.swing.JFrame;
			import java.awt.CardLayout;
			import java.awt.GridBagLayout;
			import javax.swing.JPanel;
			import javax.swing.JTabbedPane;
			import java.awt.Window.Type;
			import javax.swing.border.BevelBorder;
			import java.awt.SystemColor;
			import javax.swing.border.TitledBorder;
			import javax.swing.border.EtchedBorder;
			import java.awt.Color;
			import java.awt.Toolkit;
			import java.awt.Label;
			import java.awt.Panel;
			import javax.swing.JTextField;
			import javax.swing.JButton;
			import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
		import java.awt.event.ActionEvent;
		import java.awt.Font;

			@SuppressWarnings("unused")
			public class RoofBuilder {

				private JFrame frmRoofBuilder;
				private JTextField textField;
				private JTextField textField_1;
				private JTextField textField_2;
				private JTextField textField_3;
				private JTextField textField_4;
				private JTextField textField_5;
				private JTextField textField_6;
				private JTextField textField_7;
				private JTextField textField_8;
				private JTextField textField_12;
				private JTextField textField_13;
				private JTextField textField_14;
				private JTextField textField_9;
				private JTextField textField_10;

				/**
				 * Launch the application.
				 */
				public static void main(String[] args) {
					EventQueue.invokeLater(new Runnable() {
						public void run() {
							try {
								RoofBuilder window = new RoofBuilder();
								window.frmRoofBuilder.setVisible(true);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					});
				}

				/**
				 * Create the application.
				 */
				public RoofBuilder() {
					initialize();
				}

				/**
				 * Initialize the contents of the frame.
				 */
				private void initialize() {
					frmRoofBuilder = new JFrame();
					frmRoofBuilder.setIconImage(Toolkit.getDefaultToolkit().getImage(RoofBuilder.class.getResource("/phreplit/logo_40px.png")));
					frmRoofBuilder.getContentPane().setBackground(SystemColor.activeCaption);
					frmRoofBuilder.setForeground(SystemColor.activeCaption);
					frmRoofBuilder.setTitle("Roof Builder - 0.0.0.2v - Metragem e Calculo para Telhado Residencial");
					frmRoofBuilder.setResizable(false);
					frmRoofBuilder.setBounds(100, 100, 860, 581);
					frmRoofBuilder.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frmRoofBuilder.getContentPane().setLayout(null);
					
					JPanel panel = new JPanel();
					panel.setBackground(SystemColor.activeCaption);
					panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "1. Calcular o M\u00B2 de Telhado Res. [4 L. Iguais]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
					panel.setBounds(10, 10, 270, 282);
					frmRoofBuilder.getContentPane().add(panel);
					panel.setLayout(null);
					
					textField = new JTextField();
					textField.setBounds(10, 56, 181, 19);
					panel.add(textField);
					textField.setColumns(10);
					
					textField_1 = new JTextField();
					textField_1.setBounds(10, 105, 181, 19);
					panel.add(textField_1);
					textField_1.setColumns(10);
					
					textField_2 = new JTextField();
					textField_2.setBounds(10, 152, 181, 19);
					panel.add(textField_2);
					textField_2.setColumns(10);
					
					JButton btnNewButton = new JButton("Calcular");
					btnNewButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int mult2 = Integer.parseInt(textField.getText())*Integer.parseInt(textField_1.getText());
							textField_2.setText(String.valueOf(mult2));
						}
					});
					btnNewButton.setBounds(10, 184, 85, 21);
					panel.add(btnNewButton);
					
					JButton btnNewButton_1 = new JButton("Resetar");
					btnNewButton_1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							textField.setText("");
							textField_1.setText("");
							textField_2.setText("");
							
						}
					});
					btnNewButton_1.setBounds(106, 184, 85, 21);
					panel.add(btnNewButton_1);
					
					JLabel lblNewLabel = new JLabel("Digite o comprimento do telhado.:");
					lblNewLabel.setBounds(10, 33, 181, 13);
					panel.add(lblNewLabel);
					
					JLabel lblNewLabel_1 = new JLabel("Digite a largura do telhado.:");
					lblNewLabel_1.setBounds(10, 82, 181, 13);
					panel.add(lblNewLabel_1);
					
					JLabel lblNewLabel_2 = new JLabel("Resultado - Os metros quadrados equivalem a.:");
					lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 9));
					lblNewLabel_2.setBounds(10, 129, 250, 13);
					panel.add(lblNewLabel_2);
					
					JPanel panel_4 = new JPanel();
					panel_4.setBackground(SystemColor.activeCaption);
					panel_4.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "3. Calcular Quantidade e Tipo de Telha por M\u00B2", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
					panel_4.setBounds(10, 302, 270, 232);
					frmRoofBuilder.getContentPane().add(panel_4);
					panel_4.setLayout(null);
					
					JLabel lblNewLabel_12 = new JLabel("Digite os metros quadrados obtidos.:");
					lblNewLabel_12.setBounds(10, 22, 250, 13);
					panel_4.add(lblNewLabel_12);
					
					JLabel lblNewLabel_15 = new JLabel("Digite a quantidade de telhas referente");
					lblNewLabel_15.setFont(new Font("Tahoma", Font.BOLD, 9));
					lblNewLabel_15.setBounds(10, 69, 235, 13);
					panel_4.add(lblNewLabel_15);
					
					JLabel lblNewLabel_16 = new JLabel("ao tipo de telha por M² [Tabela de Conversão].:");
					lblNewLabel_16.setFont(new Font("Tahoma", Font.BOLD, 8));
					lblNewLabel_16.setBounds(10, 92, 235, 13);
					panel_4.add(lblNewLabel_16);
					
					JLabel lblNewLabel_17 = new JLabel("Resultado - A quantidade de telhas será de (n) telha(s).:");
					lblNewLabel_17.setFont(new Font("Tahoma", Font.BOLD, 8));
					lblNewLabel_17.setBounds(10, 149, 235, 13);
					panel_4.add(lblNewLabel_17);
					
					textField_12 = new JTextField();
					textField_12.setBounds(10, 40, 180, 19);
					panel_4.add(textField_12);
					textField_12.setColumns(10);
					
					textField_13 = new JTextField();
					textField_13.setBounds(10, 115, 180, 19);
					panel_4.add(textField_13);
					textField_13.setColumns(10);
					
					textField_14 = new JTextField();
					textField_14.setBounds(10, 172, 180, 19);
					panel_4.add(textField_14);
					textField_14.setColumns(10);
					
					JButton btnNewButton_8 = new JButton("Calcular");
					btnNewButton_8.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int mult8 = Integer.parseInt(textField_12.getText())*Integer.parseInt(textField_13.getText());
							textField_14.setText(String.valueOf(mult8));
						}
					});
					btnNewButton_8.setBounds(10, 201, 85, 21);
					panel_4.add(btnNewButton_8);
					
					JButton btnNewButton_9 = new JButton("Resetar");
					btnNewButton_9.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							textField_12.setText("");
							textField_13.setText("");
							textField_14.setText("");
							
						}
					});
					btnNewButton_9.setBounds(105, 201, 85, 21);
					panel_4.add(btnNewButton_9);
					
					JPanel panel_5 = new JPanel();
					panel_5.setBackground(SystemColor.activeCaption);
					panel_5.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Tabela de Conversao", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
					panel_5.setBounds(290, 302, 264, 232);
					frmRoofBuilder.getContentPane().add(panel_5);
					panel_5.setLayout(null);
					
					JLabel lblNewLabel_13 = new JLabel("Telha Americana");
					lblNewLabel_13.setBounds(10, 58, 133, 13);
					panel_5.add(lblNewLabel_13);
					
					JLabel lblNewLabel_18 = new JLabel("Telha Colonial");
					lblNewLabel_18.setBounds(10, 81, 133, 13);
					panel_5.add(lblNewLabel_18);
					
					JLabel lblNewLabel_19 = new JLabel("Telha Italiana");
					lblNewLabel_19.setBounds(10, 104, 133, 13);
					panel_5.add(lblNewLabel_19);
					
					JLabel lblNewLabel_20 = new JLabel("Telha Portuguesa");
					lblNewLabel_20.setBounds(10, 127, 133, 13);
					panel_5.add(lblNewLabel_20);
					
					JLabel lblNewLabel_7 = new JLabel("Telha Romana");
					lblNewLabel_7.setBounds(10, 150, 133, 13);
					panel_5.add(lblNewLabel_7);
					
					JLabel lblNewLabel_9 = new JLabel("Telha Outro Modelo");
					lblNewLabel_9.setBounds(10, 173, 133, 13);
					panel_5.add(lblNewLabel_9);
					
					JLabel lblNewLabel_11 = new JLabel("12 telhas por 1M²");
					lblNewLabel_11.setBounds(153, 58, 111, 13);
					panel_5.add(lblNewLabel_11);
					
					JLabel lblNewLabel_14 = new JLabel("16 telhas por 1M²");
					lblNewLabel_14.setBounds(153, 81, 111, 13);
					panel_5.add(lblNewLabel_14);
					
					JLabel lblNewLabel_21 = new JLabel("14 telhas por 1M²");
					lblNewLabel_21.setBounds(153, 104, 111, 13);
					panel_5.add(lblNewLabel_21);
					
					JLabel lblNewLabel_22 = new JLabel("17 telhas por 1M²");
					lblNewLabel_22.setBounds(153, 127, 111, 13);
					panel_5.add(lblNewLabel_22);
					
					JLabel lblNewLabel_23 = new JLabel("16 telhas por 1M²");
					lblNewLabel_23.setBounds(153, 150, 111, 13);
					panel_5.add(lblNewLabel_23);
					
					JLabel lblNewLabel_24 = new JLabel("(N) telhas por 1M²");
					lblNewLabel_24.setBounds(153, 173, 111, 13);
					panel_5.add(lblNewLabel_24);
					
					JPanel panel_7 = new JPanel();
					panel_7.setBackground(SystemColor.activeCaption);
					panel_7.setBorder(new TitledBorder(null, "Setup", TitledBorder.LEADING, TitledBorder.TOP, null, null));
					panel_7.setBounds(564, 302, 270, 232);
					frmRoofBuilder.getContentPane().add(panel_7);
					panel_7.setLayout(null);
					
					JButton btnNewButton_14 = new JButton("Info");
					btnNewButton_14.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							JOptionPane.showMessageDialog(
									null,"Info\n"
							        +"\nPara calcular o metro quadrado do telhado com 4 lados iguais [metragem igual] fazemos o calculo Comprimento x Largura."
						    	    +"\nPara calcular o metro quadrado com 4 lados diferentes [metragem diferente] somamos os dois lados paralelos, "
						    	    +"\nsomamos o comprimento com comprimento e dividimos por 2 tirando assim a media, "
						    	    +"\nfazemos o mesmo com a largura, somamos a largura com largura e dividimos por 2 tirando a media, "
						    	    +"\ne com os resultados da media dos lados paralelos (largura e comprimento) "
						    	    +"\nmultiplicamos os dois lados parelos Comprimento x Largura e assim obtemos os metros quadrados de um telhado com 4 lados diferentes."
						    	    +"\nPara calcular a Quantidade de Telhas por Metro Quadrado: \n"
						    	    +"\nTendo como base uma telha americana com dimensoes (43cx26l) em centimetros em vista de eixo horizontal, "
						    	    +"\ne sabendo que calcular um metro quadrado de um telhado sera C x L entao 1 MQ = 12 telhas, "
						    	    +"\nassim um metro quadrado tem 12 telhas entao essa sera a medida padrao. 12 x tantos metros quadrados = a quantidade de telhas por metro quadrado."
						    	    +"\nPara calcular a Telha Colonial: 1 M² = 16 telhas."
						    	    +"\nPara calcular a Telha Italiana: 1 M² = 14 telhas."
						    	    +"\nPara calcular a Telha Portuguesa: 1 M² = 17 telhas."
						    	    +"\nPara calcular a Telha Romana: "
						    	    +"\nTendo como base uma telha romana com dimensoes (40cx21l) em centimetros em vista de eixo horizontal, "
						    	    +"\ne sabendo que calcular um metro quadrado de um telhado sera C x L entao 1 MQ = 16 telhas,"
						    	    +"\n assim um metro quadrado tem 16 telhas entao essa sera a medida padrao. 16 x tantos metros quadrados = a quantidade de telhas por metro quadrado.\n"
						    	    +"\nInformações Importantes: \n"
						    	    +"\nObs: Este software foi desenvolvido com variaveis inteiras, então nao permite a inserção de numero e virgula (ex: 2,90 metros mude para 3 metros)."
						    	    +"\nObs: O calculo do metro quadrado de telhado residencial neste software é feito sem o calculo da inclinação. "
						    	    +"\nSe o calculo do metro quadrado for feito com a inclinação, com o aumentar do grau de inclinação do telhado, "
						    	    +"\nira ocorrer um aumento na quantidade de telhas necessarias para telhar e construir um telhado residencial."
						    	    +"\nObs: a instalação, construção e dimensionamento de um telhado residencial requer um profissional qualificado e formado, como um engenheiro civil. \n"
						    	    +"\nPadrão de telhas por Metro Quadrado e Quantidade de Telhas: \n"
						    	    +"\n A quantidade de telhas pode variar para mais ou para menos, a depender das dimensões da telha escolhida, "
						    	    +"\nentão veja que no caso da instalação das telhas coloniais, sua arrumação (encaixe) das telhas vai ser feita com duas camadas de telhas, "
						    	    +"\no que pode acarretar na variação (para mais ou para menos) da quantidade de telhas necessarias para telhar um metro quadrado. "
						    	    +"\n Havendo assim uma possivel diferença no padrão e na quantidade de telhas do metro quadrado para a telha colonial como descrito acima.\n"
						    	    +"\nModelo de telhas por Metro Quadrado e Quantidade de Telhas: \n"
						    	    +"\n Caso queira calcular um novo modelo de telha que não esta na tabela de conversão, sera necessario saber as dimensões do novo modelo de telha "
						    	    +"\ne saber quantas telhas serão necessarias para telhar um metro quadrado, então sera (N) telhas por 1M².");
						}
					});
					btnNewButton_14.setBounds(95, 67, 85, 21);
					panel_7.add(btnNewButton_14);
					
					JButton btnNewButton_15 = new JButton("Sobre");
					btnNewButton_15.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							JOptionPane.showMessageDialog(
									null,"Software:  Roof Builder - Metragem e Calculo para Telhado Residencial\n"
									+"\nAuthor: PHNO"
									+"\nData Release: 31/10/2024"
									+"\nVersao Codigo: 0.0.0.2v"
									+"\nReplit: @PHNO, @PHREPLIT"
									+"\nE-mail: phreplit@gmail.com");
						}
					});
					btnNewButton_15.setBounds(95, 98, 85, 21);
					panel_7.add(btnNewButton_15);
					
					JButton btnNewButton_16 = new JButton("Limpar Dados");
					btnNewButton_16.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							textField.setText("");
							textField_1.setText("");
							textField_2.setText("");
							textField_3.setText("");
							textField_4.setText("");
							textField_5.setText("");
							textField_6.setText("");
							textField_7.setText("");
							textField_8.setText("");
							textField_9.setText("");
							textField_10.setText("");
							textField_12.setText("");
							textField_13.setText("");
							textField_14.setText("");
							
						}
					});
					btnNewButton_16.setBounds(81, 129, 112, 21);
					panel_7.add(btnNewButton_16);
					
					JPanel panel_1 = new JPanel();
					panel_1.setBackground(SystemColor.activeCaption);
					panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "2. Calcular o M\u00B2 de T. Res. [4 L. Diferentes]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
					panel_1.setBounds(290, 10, 264, 282);
					frmRoofBuilder.getContentPane().add(panel_1);
					panel_1.setLayout(null);
					
					JLabel lblNewLabel_3 = new JLabel("Digite o comprimento do telhado [Lado 1].:");
					lblNewLabel_3.setBounds(10, 30, 244, 13);
					panel_1.add(lblNewLabel_3);
					
					JLabel lblNewLabel_4 = new JLabel("Digite o comprimento do telhado [Lado 2].:");
					lblNewLabel_4.setBounds(10, 71, 244, 13);
					panel_1.add(lblNewLabel_4);
					
					JLabel lblNewLabel_5 = new JLabel("Digite a largura do telhado [Lado 3].:");
					lblNewLabel_5.setBounds(10, 114, 244, 13);
					panel_1.add(lblNewLabel_5);
					
					textField_3 = new JTextField();
					textField_3.setBounds(10, 46, 180, 19);
					panel_1.add(textField_3);
					textField_3.setColumns(10);
					
					textField_4 = new JTextField();
					textField_4.setBounds(10, 92, 180, 19);
					panel_1.add(textField_4);
					textField_4.setColumns(10);
					
					textField_5 = new JTextField();
					textField_5.setBounds(10, 134, 180, 19);
					panel_1.add(textField_5);
					textField_5.setColumns(10);
					
					JButton btnNewButton_2 = new JButton("Calcular");
					btnNewButton_2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int vartwo = 2;			                
							int mult3 = Integer.parseInt(textField_3.getText())+Integer.parseInt(textField_4.getText());
			                int mult4 = mult3 / vartwo;			                
			                int mult5 = Integer.parseInt(textField_5.getText())+Integer.parseInt(textField_9.getText());
			                int mult6 = mult5 / vartwo;
			                int result = mult4 * mult6;			                
							textField_10.setText(String.valueOf(result));

						}
					});
					btnNewButton_2.setBounds(10, 240, 85, 21);
					panel_1.add(btnNewButton_2);
					
					JButton btnNewButton_3 = new JButton("Resetar");
					btnNewButton_3.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							textField_3.setText("");
							textField_4.setText("");
							textField_5.setText("");
							textField_9.setText("");
							textField_10.setText("");
							
						}
					});
					btnNewButton_3.setBounds(105, 240, 85, 21);
					panel_1.add(btnNewButton_3);
					
					JLabel lblNewLabel_25 = new JLabel("Digite a largura do telhado [Lado 4].:");
					lblNewLabel_25.setBounds(10, 156, 244, 13);
					panel_1.add(lblNewLabel_25);
					
					textField_9 = new JTextField();
					textField_9.setBounds(10, 172, 180, 19);
					panel_1.add(textField_9);
					textField_9.setColumns(10);
					
					JLabel lblNewLabel_26 = new JLabel("Resultado - Os metros quadrados equivalem a.:");
					lblNewLabel_26.setFont(new Font("Tahoma", Font.BOLD, 9));
					lblNewLabel_26.setBounds(10, 195, 244, 13);
					panel_1.add(lblNewLabel_26);
					
					textField_10 = new JTextField();
					textField_10.setBounds(10, 211, 180, 19);
					panel_1.add(textField_10);
					textField_10.setColumns(10);
					
					JPanel panel_2 = new JPanel();
					panel_2.setBackground(SystemColor.activeCaption);
					panel_2.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Calculadora Basica", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
					panel_2.setBounds(564, 10, 271, 280);
					frmRoofBuilder.getContentPane().add(panel_2);
					panel_2.setLayout(null);
					
					JLabel lblNewLabel_6 = new JLabel("Digite um numero.:");
					lblNewLabel_6.setBounds(10, 33, 110, 13);
					panel_2.add(lblNewLabel_6);
					
					textField_6 = new JTextField();
					textField_6.setBounds(10, 56, 110, 19);
					panel_2.add(textField_6);
					textField_6.setColumns(10);
					
					textField_7 = new JTextField();
					textField_7.setBounds(10, 107, 110, 19);
					panel_2.add(textField_7);
					textField_7.setColumns(10);
					
					textField_8 = new JTextField();
					textField_8.setBounds(10, 160, 110, 19);
					panel_2.add(textField_8);
					textField_8.setColumns(10);
					
					JLabel lblNewLabel_8 = new JLabel("Digite outro numero.:");
					lblNewLabel_8.setBounds(10, 85, 137, 13);
					panel_2.add(lblNewLabel_8);
					
					JLabel lblNewLabel_10 = new JLabel("Resultado.:");
					lblNewLabel_10.setBounds(10, 137, 110, 13);
					panel_2.add(lblNewLabel_10);
					
					JButton btnNewButton_4 = new JButton("Somar");
					btnNewButton_4.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int soma = Integer.parseInt(textField_6.getText())+Integer.parseInt(textField_7.getText());
							textField_8.setText(String.valueOf(soma));
						}
					});
					btnNewButton_4.setBounds(148, 55, 85, 21);
					panel_2.add(btnNewButton_4);
					
					JButton btnNewButton_5 = new JButton("Resetar");
					btnNewButton_5.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							textField_6.setText("");
							textField_7.setText("");
							textField_8.setText("");
							
						}
					});
					btnNewButton_5.setBounds(10, 189, 85, 21);
					panel_2.add(btnNewButton_5);
					
					JButton btnNewButton_6 = new JButton("Subtrair");
					btnNewButton_6.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int sub = Integer.parseInt(textField_6.getText())-Integer.parseInt(textField_7.getText());
							textField_8.setText(String.valueOf(sub));
						}
					});
					btnNewButton_6.setBounds(148, 85, 85, 21);
					panel_2.add(btnNewButton_6);
					
					JButton btnNewButton_7 = new JButton("Dividir");
					btnNewButton_7.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int div = Integer.parseInt(textField_6.getText())/Integer.parseInt(textField_7.getText());
							textField_8.setText(String.valueOf(div));
						}
					});
					btnNewButton_7.setBounds(148, 117, 85, 21);
					panel_2.add(btnNewButton_7);
					
					JButton btnNewButton_10 = new JButton("Multiplicar");
					btnNewButton_10.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int mult = Integer.parseInt(textField_6.getText())*Integer.parseInt(textField_7.getText());
							textField_8.setText(String.valueOf(mult));
						}
					});
					btnNewButton_10.setBounds(148, 148, 85, 21);
					panel_2.add(btnNewButton_10);
				}
			}
